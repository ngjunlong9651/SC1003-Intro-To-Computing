from sense_hat import SenseHat
import time
from time import sleep

## Exercise 6A & 6B
sense = SenseHat()
#sense.clear()
x = 3
y = 3
w = (255,255,255)
b = (0,0,0)
r = (255,0,0)
g = (0,255,0)
#board = [
#         [b,b,b,b,b,b,b,b], 
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b], 
#         [b,b,b,b,b,b,b,b] 
#                          ]
#board[y][x] = w
#board_1D = sum(board,[])
#print(board_1D)
#sense.set_pixels(board_1D)
#while True:
#  pitch = sense.get_orientation()['pitch']
#  roll = sense.get_orientation()['roll']
#  print("pitch = {0} roll = {0}".format(round(pitch,0), round(roll,0)))
#  board[x][y] = w
#  board_1D = sum(board,[])
#  print(board_1D)
#  sense.set_pixels(board_1D)
#  sleep(0.05)






## Exercise 6C
#sense.clear()
#def move_marble(pitch,roll,x,y): 
#  new_x = x 
#  new_y = y 
#  if 1 < pitch < 179 and x != 0: 
#     new_x -= 1 # This moves leftwards
#  elif 359 > pitch > 179 and x != 7 : 
#     new_x += 1 # This moves rightwards
#     
#  if 1 < roll < 179 and y != 7: 
#     new_y += 1 # This moves upwards
#  elif 359 > roll > 179 and y != 0 : 
#     new_y -= 1 # This moves downwards
#
#  return new_x,new_y 
#
#r=(0,0,0)
#b=(0,0,0)
#w=(255,255,255)
#
#board = [[b,b,b,b,b,b,b,b], 
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b],
#         [b,b,b,b,b,b,b,b], 
#         [b,b,b,b,b,b,b,b] ]
#  
#game_over = False
#x = 2
#y = 2
#while not game_over:
#  pitch = sense.get_orientation()['pitch']
#  roll = sense.get_orientation()['roll']
#  #print("pitch = {0} roll = {0}".format(round(pitch,0), round(roll,0)))
#  x,y = move_marble(pitch,roll,x,y)
#  board[x][y] = w
#  sense.set_pixels(sum(board,[]))
#  sleep(0.05)
#  board[x][y] = b
  
## Exercise 6D
#def check_wall(x,y,new_x,new_y):
#  if board[new_y][new_x] != r:
#    return new_x,new_y
#  elif board[new_y][x]!=r:
#    return x,new_y
#  elif board[new_x][y] !=r:
#    return new_x,y
#  else:
#    return x,y

#def move_marble(pitch,roll,x,y): 
#  new_x = x 
#  new_y = y 
#  if 1 < pitch < 179 and x != 0: 
#     new_x -= 1 # This moves leftwards
#  elif 359 > pitch > 179 and x != 7 : 
#     new_x += 1 # This moves rightwards
#     
#  if 1 < roll < 179 and y != 7: 
#     new_y += 1 # This moves upwards
#  elif 359 > roll > 179 and y != 0 : 
#     new_y -= 1 # This moves downwards
#  new_x,new_y = check_wall(x,y,new_x,new_y)
#  return new_x,new_y

  
  
#board = [[r,r,r,r,r,r,r,r], 
#         [r,b,b,b,b,b,b,r],
#         [r,b,r,b,b,b,b,r],
#         [r,b,r,b,r,b,b,r],
#         [r,b,b,b,b,b,b,r],
#         [r,b,b,b,b,r,b,r],
#         [r,b,b,b,r,r,b,r], 
#         [r,r,r,r,r,r,r,r]]
#         
#game_over = False
#x = 2
#y = 2
#while not game_over:
#  pitch = sense.get_orientation()['pitch']
#  roll = sense.get_orientation()['roll']
#  #print("pitch = {0} roll = {0}".format(round(pitch,0), round(roll,0)))
#  x,y = move_marble(pitch,roll,x,y)
#  board[x][y] = w
#  sense.set_pixels(sum(board,[]))
#  sleep(0.05)
#  board[x][y] = b
  
  
## Lab 6E
def check_wall(x,y,new_x,new_y):
  if board[new_y][new_x] != r:
    return new_x,new_y
  elif board[new_y][x]!=r:
    return x,new_y
  elif board[new_x][y] !=r:
    return new_x,y
  else:
    return x,y

def move_marble(pitch,roll,x,y): 
  new_x = x 
  new_y = y 
  if 1 < pitch < 179 and x != 0: 
     new_x -= 1 # This moves leftwards
  elif 359 > pitch > 179 and x != 7 : 
     new_x += 1 # This moves rightwards
     
  if 1 < roll < 179 and y != 7: 
     new_y += 1 # This moves upwards
  elif 359 > roll > 179 and y != 0 : 
     new_y -= 1 # This moves downwards
  new_x,new_y = check_wall(x,y,new_x,new_y)
  return new_x,new_y

  
  
board = [[r,r,r,r,r,r,r,r], 
         [r,g,r,b,b,b,b,r],
         [r,b,r,b,b,b,b,r],
         [r,b,r,b,b,b,b,r],
         [r,b,b,b,b,b,b,r],
         [r,b,b,b,b,b,b,r],
         [r,r,r,r,r,b,b,r], 
         [r,r,r,r,r,r,r,r]]
         
game_over = False
x = 3
y = 3
while not game_over:
  pitch = sense.get_orientation()['pitch']
  roll = sense.get_orientation()['roll']
  #print("pitch = {0} roll = {0}".format(round(pitch,0), round(roll,0)))
  x,y = move_marble(pitch,roll,x,y)
  if board[y][x] == g:
    game_over = True
  else:
    board[x][y] = w
    sense.set_pixels(sum(board,[]))
    sleep(0.05)
    board[x][y] = b
    
sense.show_message("yay")