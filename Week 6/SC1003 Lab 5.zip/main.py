## Lab 5a 

from textcolor import get_color
from sense_hat import SenseHat
sense = SenseHat()
sense.set_rotation(180)

##Lab 5B

red_int = get_color("red")
blue_int = get_color("blue")
green_int = get_color("green")
msg_color = (red_int, blue_int, green_int)
print(msg_color)
sense.show_message("Hello", text_colour	= (msg_color))
    